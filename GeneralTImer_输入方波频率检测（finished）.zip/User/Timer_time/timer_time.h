#ifndef __TIMER_TIME_H
#define __TIMER_TIME_H

#include "stm32f10x.h"

#define ETR_GPIO_CLK  RCC_APB2Periph_GPIOD 
#define ETR_GPIO_Pin   GPIO_Pin_2
#define ETR_GPIO_PORT  GPIOD
// 0.5Hz 2s
#define GENERAL_TIM_Period       10000-1   
#define GENERAL_TIM_Prescaler  14400-1       


void GENERAL_TIM_Init(void);

#endif
