#ifndef __TIMER_TIME_H
#define __TIMER_TIME_H

#include "stm32f10x.h"

// 10000 = 72000000/(BASIC_TIM_Prescaler+1)(BASIC_TIM_Period+1)
// 1/10000s 0.0001s 0.1ms 
#define BASIC_TIM_Period  (100-1) 
#define BASIC_TIM_Prescaler (72-1)
#define	BASIC_TIM TIM6

void BASIC_TIM_Init(void);
#endif
