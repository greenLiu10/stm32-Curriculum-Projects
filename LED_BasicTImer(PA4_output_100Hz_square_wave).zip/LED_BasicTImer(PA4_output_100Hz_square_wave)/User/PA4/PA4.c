#include "PA4.h"

void PA4_Config(void){
	GPIO_InitTypeDef  GPIO_InitStruct;
	// �� GPIOB �˿ڵ�ʱ��
	RCC_APB2PeriphClockCmd(Wave_GPIO_CLK, ENABLE);
	// ����IO��Ϊ���
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin=Wave_GPIO_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(Wave_GPIO_PORT, &GPIO_InitStruct);
}
	
void PA4_High(void){
	GPIO_SetBits(Wave_GPIO_PORT, Wave_GPIO_Pin);
}
void PA4_Low(void){
	GPIO_ResetBits(Wave_GPIO_PORT, Wave_GPIO_Pin);
}

