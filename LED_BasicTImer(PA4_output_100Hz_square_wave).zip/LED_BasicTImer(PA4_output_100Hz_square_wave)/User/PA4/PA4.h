#ifndef __PA4_H
#define __PA4_H

#include "stm32f10x.h"

#define Wave_GPIO_CLK   RCC_APB2Periph_GPIOA
#define Wave_GPIO_Pin   GPIO_Pin_4
#define Wave_GPIO_PORT  GPIOA

void PA4_Config(void);
void PA4_High(void);
void PA4_Low(void);
	
#endif
