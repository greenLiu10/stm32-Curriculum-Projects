#include "stm32f10x.h" 
#include "timer_time.h"
#include "PA4.h"

uint16_t time=0;

int main(void)
{
	  static uint8_t i=0;
	  PA4_Config();
	  // �����ж���Ϊ0
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);	
	  
	  BASIC_TIM_Init();  
	
	  while(1)
		{
				if( time > 50 ) // 5ms
				{
					time = 0;
					switch(i)
					{
						case 0: PA4_High();    // PA4����ߵ�ƽ
										i++;
										break;
						case 1: PA4_Low();
										i=0;
										break;
					  //case 0:LED_ON();i++;break;
						//case 1:LED_OFF();i=0;break;
					
					}
				}		
	  	}
}






