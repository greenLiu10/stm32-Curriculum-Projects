stm32 题目复习

- [x] Modify LED to PC13,register programming

- [x]  Configure PC13 as a pull-up input pin by 2 method refer to the example above,

  1):Firmware library programming

  2):Register Programming

- [x] LED turn on and off alternately (Based on FwLik and Modularization,use delay,s delay.h)---8 states.
- [x] Press the key to control the change between LED on and off (in the report, the programming flowchart is necessary too).

- [x] PA4引脚输出100HZ方波，提交视频代码;
- [x] 使用ETR引脚测量外部信号的频率，实现串口打印;提交视频和代码;
- [ ] 使用输入捕获功能实现脉宽测量，串口打印;提交视频和代码;
- [ ] 使用输出比较功能实现呼吸灯，提交视频和代码;

