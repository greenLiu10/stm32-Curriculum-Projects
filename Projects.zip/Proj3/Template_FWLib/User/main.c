#include "stm32f10x.h"   
#include "led.h"
#include "delay.h"

int main(void) {
    // ϵͳʱ��Ƶ��
    uint32_t SystemCoreClock = 72000000;
    delay_init(SystemCoreClock); // ��ʼ����ʱ����
		LED_GPIO_Config();
    while (1) {
      RED;
			delay_ms(1000); 
			
			GREEN;
			delay_ms(1000); 
			
			BLUE;
			delay_ms(1000); 

			YELLOW;
			delay_ms(1000); 
			
			PURPLE;
			delay_ms(1000); 
			
			CYAN;
			delay_ms(1000); 
			
			WHITE;
			delay_ms(1000); 
			
			BLACK;
			delay_ms(1000); 
    }
}


