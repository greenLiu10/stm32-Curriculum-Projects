#ifndef __LED_H
#define __LED_H

# include "stm32f10x.h"

#define R_LED_GPIO_CLK  RCC_APB2Periph_GPIOB
#define R_LED_GPIO_PORT  GPIOB
#define R_LED_GPIO_PIN  GPIO_Pin_5

#define G_LED_GPIO_CLK  RCC_APB2Periph_GPIOB
#define G_LED_GPIO_PORT  GPIOB
#define G_LED_GPIO_PIN  GPIO_Pin_0

#define B_LED_GPIO_CLK  RCC_APB2Periph_GPIOB
#define B_LED_GPIO_PORT  GPIOB
#define B_LED_GPIO_PIN  GPIO_Pin_1

//�����ɫ�Ŀ���
#define R_LED_ON GPIO_ResetBits(R_LED_GPIO_PORT,R_LED_GPIO_PIN)
#define R_LED_OFF GPIO_SetBits(R_LED_GPIO_PORT,R_LED_GPIO_PIN)
//������ɫ�Ŀ���
#define G_LED_ON GPIO_ResetBits(G_LED_GPIO_PORT,G_LED_GPIO_PIN)
#define G_LED_OFF GPIO_SetBits(G_LED_GPIO_PORT,G_LED_GPIO_PIN)
//������ɫ�Ŀ���
#define B_LED_ON GPIO_ResetBits(B_LED_GPIO_PORT,B_LED_GPIO_PIN)
#define B_LED_OFF GPIO_SetBits(B_LED_GPIO_PORT,B_LED_GPIO_PIN)

//��ɫ�Ķ���
#define RED (R_LED_ON, G_LED_OFF, B_LED_OFF)
#define GREEN (R_LED_OFF, G_LED_ON, B_LED_OFF)
#define BLUE (R_LED_OFF, G_LED_OFF, B_LED_ON)
#define YELLOW (R_LED_ON, G_LED_ON, B_LED_OFF)
#define PURPLE (R_LED_ON, G_LED_OFF, B_LED_ON)
#define CYAN (R_LED_OFF, G_LED_ON, B_LED_ON)
#define WHITE (R_LED_ON, G_LED_ON, B_LED_ON)
#define BLACK (R_LED_OFF, G_LED_OFF, B_LED_OFF)

void LED_GPIO_Config(void);

#endif
