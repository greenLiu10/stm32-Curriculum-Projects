# include "led.h"

void LED_GPIO_Config(void){
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	//��ʱ��
	RCC_APB2PeriphClockCmd(R_LED_GPIO_CLK, ENABLE);
	RCC_APB2PeriphClockCmd(G_LED_GPIO_CLK, ENABLE);
	RCC_APB2PeriphClockCmd(B_LED_GPIO_CLK, ENABLE);

	// ����
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = R_LED_GPIO_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(R_LED_GPIO_PORT, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = G_LED_GPIO_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(G_LED_GPIO_PORT, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = B_LED_GPIO_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(B_LED_GPIO_PORT, &GPIO_InitStruct);
	
	//��ʼʱ��Ҫ�ر���
	GPIO_SetBits(R_LED_GPIO_PORT,R_LED_GPIO_PIN);
	GPIO_SetBits(G_LED_GPIO_PORT,G_LED_GPIO_PIN);
	GPIO_SetBits(B_LED_GPIO_PORT,B_LED_GPIO_PIN);

}

