# include "led.h"

void LED_GPIO_Config(void){
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	//��ʱ��
	RCC_APB2PeriphClockCmd(R_LED_GPIO_CLK, ENABLE);
	RCC_APB2PeriphClockCmd(B_LED_GPIO_CLK, ENABLE);	

	// ����
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = R_LED_GPIO_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(R_LED_GPIO_PORT, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = B_LED_GPIO_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(B_LED_GPIO_PORT, &GPIO_InitStruct);
	
	// ��ʼ������
	R_LED_OFF;
	B_LED_OFF;
}

void digitalToggle(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin) {
	
    uint8_t state = GPIO_ReadOutputDataBit(GPIOx, GPIO_Pin) == Bit_SET ? 1 : 0;

    if (state) {
        GPIO_ResetBits(GPIOx, GPIO_Pin);
    } else {
        GPIO_SetBits(GPIOx, GPIO_Pin);
    }
}

