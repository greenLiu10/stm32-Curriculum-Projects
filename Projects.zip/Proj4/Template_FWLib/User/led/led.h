#ifndef __LED_H
#define __LED_H

# include "stm32f10x.h"

#define R_LED_GPIO_CLK  RCC_APB2Periph_GPIOB
#define R_LED_GPIO_PORT  GPIOB
#define R_LED_GPIO_PIN  GPIO_Pin_5

#define B_LED_GPIO_CLK  RCC_APB2Periph_GPIOB
#define B_LED_GPIO_PORT  GPIOB
#define B_LED_GPIO_PIN  GPIO_Pin_1


//�����ɫ�Ŀ���
#define R_LED_ON GPIO_ResetBits(R_LED_GPIO_PORT, R_LED_GPIO_PIN)
#define R_LED_OFF GPIO_SetBits(R_LED_GPIO_PORT, R_LED_GPIO_PIN)
#define R_LED_TOGGLE() digitalToggle(R_LED_GPIO_PORT, R_LED_GPIO_PIN)

//������ɫ�Ŀ���
#define B_LED_ON GPIO_ResetBits(B_LED_GPIO_PORT, B_LED_GPIO_PIN)
#define B_LED_OFF GPIO_SetBits(B_LED_GPIO_PORT, B_LED_GPIO_PIN)
#define B_LED_TOGGLE() digitalToggle(B_LED_GPIO_PORT, B_LED_GPIO_PIN)

void LED_GPIO_Config(void);
void digitalToggle(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

#endif
